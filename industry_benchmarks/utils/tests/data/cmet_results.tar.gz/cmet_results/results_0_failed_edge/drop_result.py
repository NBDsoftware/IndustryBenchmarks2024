import json
from gufe.tokenization import JSON_HANDLER
import pathlib
filepath = 'lig_CHEMBL3402745_200_5_solvent_lig_CHEMBL3402744_300_4_solvent_solvent.json'
ru = json.load(open(filepath, 'rb'), cls=JSON_HANDLER.decoder)
print(ru["unit_results"])
del ru["unit_results"]["ProtocolUnitResult-8719669074a74ba09602a719280871d9"]

json.dump(
        ru,
        pathlib.Path(filepath).open(mode="w"),
        cls=JSON_HANDLER.encoder,
    )
